/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ractoc.fs.components.es;

import com.ractoc.fs.es.EntityComponent;

/**
 *
 * @author racto_000
 */
public class BoundedEntityComponent implements EntityComponent {
    
}
