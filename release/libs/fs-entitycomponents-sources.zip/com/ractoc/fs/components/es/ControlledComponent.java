package com.ractoc.fs.components.es;

import com.ractoc.fs.es.EntityComponent;

public class ControlledComponent implements EntityComponent {

}
