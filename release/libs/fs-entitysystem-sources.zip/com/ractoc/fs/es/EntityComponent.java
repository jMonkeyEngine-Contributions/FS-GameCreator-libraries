package com.ractoc.fs.es;

public interface EntityComponent {
}
