package com.ractoc.fs.es;

public class EntityException extends RuntimeException {

    public EntityException(String message) {
        super(message);
    }

}
